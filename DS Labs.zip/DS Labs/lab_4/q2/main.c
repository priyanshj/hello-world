#include<stdio.h>
#include<stdlib.h>
#include"circulur.h"

main()
{
 int i,j,k,num;

 scanf("%d",&num);

   for(i=0;i<num;i++)
   {
    insert(i);
   }
   
   print();
}
