#include<stdio.h>
#include<stdlib.h>

struct node{
int data;
struct node* lnk;
};

struct node* head = NULL;
struct node* tail = NULL;

struct node* XOR(struct node* a,struct node* b)
 {
   return (struct node*)((unsigned int)(a)^(unsigned int)(b));
 }

void insert(int x);
void print();
void print_rev();

main()
{
int i,j,num=0;

scanf("%d",&num);
 for(i=0;i<num;i++)
  {
   scanf("%d",&j);
    insert(j); 
  }
print();
print_rev();
}

void insert(int x)
{
 struct node* temp;
 temp=(struct node*)malloc(sizeof(struct node*));
 temp->data=x;
 temp->lnk=XOR(head,NULL);

 if(head == NULL)
  { 
    tail = temp;
  }

  if(head!=NULL)
  {
   struct node* next=XOR((head)->lnk,NULL);
    head->lnk=XOR(temp,next);
  }
   head=temp;
}

void print()
{
 struct node* temp=head;
 struct node* next;
 struct node* prev=NULL;

 while(temp!=NULL)
 {
   printf("%d ",temp->data);
   next=XOR(prev,temp->lnk);
   prev=temp;
   temp=next;
 }
printf("\n");
}

void print_rev()
{
	struct node *temp = tail;
	struct node *prev = NULL;
	struct node *next;
	printf("Linked List Printed From LEFT TO RIGHT:\n");
	
	while(temp != NULL)
	{
		printf("%d ", temp->data);
		
		next = XOR(prev, temp->lnk);
		prev = temp;
		temp = next;		
	}
	printf("\n");	
}
