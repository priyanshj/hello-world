struct node{
int data;
struct node* next; 
};

struct node* head;
struct node* key;

void insert(int x);
void del();
void print();
