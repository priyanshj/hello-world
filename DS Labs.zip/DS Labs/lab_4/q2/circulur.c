#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"circulur.h"

struct node* head=NULL;
struct node* key=NULL;

void insert(int x)
{
  struct node* temp;
  temp=(struct node*)malloc(sizeof(struct node*));

  temp->data=x;
  
  if(head==NULL)
   {
    temp->next=head;
    head=temp;
   }
  
   else
   {
    temp->next=head;

    while(temp->next != NULL)
    {
     temp=temp->next;
    } 
     key->next=head;
     head=temp;
   }
}

void print()
{
   struct node* temp;
   temp=head;
   
   while(temp->next != NULL)
   {
    printf("%d",temp->data);
    temp=temp->next;
   }
    printf("%d\n",temp->data);
    printf("%d\n",key->data);   
}
