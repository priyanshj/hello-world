struct node{
int data;
struct node* next;
struct node* prev;
};

struct node* head;
int t;


void insert(int data);
void del();
void print();
