#include<stdio.h>
#include<string.h>
#include"double.h"

main()
{
 int i,j,k,num;

  for(i=0;i<5;i++)
  {
   insert(i); 
  }
   print();
   del();
   print();
}
