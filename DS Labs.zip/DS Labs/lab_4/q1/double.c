#include<stdio.h>
#include<stdlib.h>
#include"double.h"

struct node* head=NULL;

void insert(int x)
{
 struct node* temp;
 temp=(struct node*)malloc((sizeof(struct node*)));
 temp->data=x;
 
   temp->prev=NULL;
   temp->next=head;
   //head=temp; 

   if(head != NULL)
  {
   head->prev=temp;
  }
    head=temp;
   //printf("Insertion is fine\n");
}

void print()
{
  struct node* temp;
  temp=head;

  while(temp->next != NULL) 
   {
    printf("%d",temp->data);
     temp=temp->next;
   }
    printf("%d\n",temp->data);
//printf("print is fine\n");      
}

void del()
{
 struct node* temp;
 temp=head;
 
 for(t=0;t<3;t++)
 {
  temp=temp->next; 
 }
  (temp->next)->prev=temp->prev;
  (temp->prev)->next=temp->next; 
   free(temp);
 }
