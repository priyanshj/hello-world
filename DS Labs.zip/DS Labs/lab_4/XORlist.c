#include <stdio.h>
#include <stdlib.h>

struct node
{
	int data;
	struct node* link;
};

struct node *head = NULL;
struct node *tail = NULL;

struct node* xor(struct node* a, struct node* b)
{
	return (struct node*) ((unsigned int) (a) ^ (unsigned int) (b));
}

int length()
{
        struct node *curr = head;
        struct node *prev = NULL;
        struct node *next;
        int count = 0;
        while(curr != NULL)
        {
                count++;
                next = xor(prev, curr->link);
                prev = curr;
                curr = next;
        }
        return count;
}

void Insert(int item)
{
	struct node *temp = (struct node*) malloc(sizeof(struct node));
	temp->data = item;
	printf("%d Inserted In The List\n", item);
	
	temp->link = xor(head, NULL);
	
	if(head == NULL)
	{
		tail = temp;
	}
	if(head != NULL)
	{
		struct node *next = xor(head->link, NULL);
		head->link = xor(temp, next);
	}
	
	head = temp;
}

void Insert_pos(int item, int n)
{	
	struct node *head_cpy = head;
	struct node *tail_cpy = tail;
	struct node *prev = NULL, *prev_1 = NULL,*curr = head_cpy, *curr_1 = tail_cpy, *nxt, *nxt_1;	
	int i;
	struct node *temp = (struct node*) malloc(sizeof(struct node));
	temp->data = item;
	
	if(n == 0)
	{
		temp->link = xor(tail, NULL);
		struct node *next = xor(NULL, tail->link);
		tail->link = xor(next, temp);
		tail = temp;
	}
	
	int len = length();
	if(len <= n)
	{
		temp->link = xor(head, NULL);

	        if(head == NULL)
       		{
			tail = temp;
		}
        	if(head != NULL)
        	{
                	struct node *next = xor(head->link, NULL);
                	head->link = xor(temp, next);
        	}

        	head = temp;
		
	}
	else if(n <= len && n > 0)
	{	
		int a = n;
		for(i = 0; i < length() - a; i++)
		{	
			nxt = xor(prev, curr->link);
			prev = curr;
			curr = nxt;
		}
		for(i = 0; i < n; i++)
		{
			nxt_1 = xor(prev_1, curr_1->link);
			prev_1 = curr_1;
			curr_1 = nxt_1;

		}
		printf("%d %d \n", curr->data, curr_1->data);
		
		temp->link = xor(curr, curr_1);
		curr->link = xor(xor(curr->link, curr_1), temp);
		
		curr_1->link = xor(xor(curr_1->link, curr), temp);		


	}
}

void Print_rtol()
{
	struct node *curr = head;
	struct node *prev = NULL;
	struct node *next;
	printf("Linked List Printed From RIGHT TO LEFT:\n");
	
	while(curr != NULL)
	{
		printf("%d ", curr->data);
		
		next = xor(prev, curr->link);
		prev = curr;
		curr = next;
	}
	printf("\n");
}

void Print_ltor()
{
	struct node *curr = tail;
	struct node *prev = NULL;
	struct node *next;
	printf("Linked List Printed From LEFT TO RIGHT:\n");
	
	while(curr != NULL)
	{
		printf("%d ", curr->data);
		
		next = xor(prev, curr->link);
		prev = curr;
		curr = next;		
	}
	printf("\n");	
}

void main()
{
	Insert(10);
	Insert(20);
	Insert(30);
        Insert(40);
	Insert(50);
	Insert(60);
	//Print_ltor();
	//Print_rtol();
	//Insert_pos(1, 0);
	//Print_ltor();
	//Print_rtol();
	//Insert_pos(11, 15);	
 	//Print_ltor();
	//Print_rtol();
	Insert_pos(55, 4);
	Insert_pos(22,1);
	Print_ltor();
	Print_rtol();
	return;
}
