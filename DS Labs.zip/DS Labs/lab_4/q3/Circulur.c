#include <stdio.h>
#include <stdlib.h>
#include "Circulur.h"


struct node* head = NULL;

struct node* getnode(int item)
{
	struct node *temp = (struct node*) malloc(sizeof(struct node));
	temp->data = item;
	return temp;
}

int Delete(struct node* temp)
{
	int x;	
	struct node *temp1;
	temp1 = temp->next;
	x = temp1->data;
	temp->next = temp1->next;
	return x;
}

