struct node
{
	int data;
	struct node *next;
};


struct node* head;

struct node* getnode(int item);
int Delete(struct node* temp);
