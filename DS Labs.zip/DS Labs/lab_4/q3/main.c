#include <stdio.h>
#include <stdlib.h>
#include "Circulur.h"


void main()
{
	int n, m, k, x, i = 1, j;
	struct node *temp, *temp1;
	printf(" No. of players:\n");
	scanf("%d", &n);
	
	k = n;
	//printf("%d",n);
	while(n--)
	{
		if(head == NULL)
		{
			temp = getnode(i++);
			temp1 = temp;
			head = temp;
		}
		else
		{
			temp = getnode(i++);
			temp->next = NULL;
			temp1->next = temp;
			temp1 = temp;						
		}
		
		if(n == 0)
		{
			temp->next = head;			
		}
	}	
	
	printf("VALUE OF m:\n");
	scanf("%d", &m);
	struct node *new = head;	
			
	while(k--)
	{
		if(m == 0)
		{
			for(i = 0; i < k; i++)
			{
				new = new->next;
			}
		}
		else
		{
			for(i = 0; i < m - 1; i++)
			{
				new = new->next;
			}
		}
		x = Delete(new);
		new = new->next;
		
		if(k == 0)
		{
			printf("\nWINNER IS: %d\n", x);
		}
		else
		{
			printf(" Eliminated players are %d ", x);
		}		
	}
	return;
}
