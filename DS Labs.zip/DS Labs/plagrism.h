struct node{
 int data;
 struct node* next;
};

struct node* head;
struct node* headA;
struct node* headB;

void insert(int x);
void check();
void del();
void print();
