struct node{
int data;
struct node* next;
};

struct node* head;

void insert_front(int x);
void insert_end(int x);
void insert_n(int x,int num);
void del(int x,int num);
void print();
void search(int x);
