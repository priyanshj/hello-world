#include<stdio.h>
#include<stdlib.h>
#include"list.h"

main()
{
int num;
insert_front(9);
insert_front(8);
insert_front(7);
insert_rear(10);
print();
search(8);
}
