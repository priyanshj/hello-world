// EMPLOYEE DATABASE STRUCTURE NODE FORMAT
struct EMP_DATABASE
{
	int Emp_id;
	char Emp_name[20];
	struct EMP_DATABASE *link;
};

// THIS IS HASHTABLE FORMAT 
struct HASHTABLE
{
	struct EMP_DATABASE *link;
};


// THE FUNCTION DECLARATION WHICH ARE USED IN THE PROGRAM
struct EMP_DATABASE* getnode();
void Search(struct HASHTABLE hashtable[], int Emp_id);
void Insert(struct HASHTABLE hashtable[], int Emp_id, char Emp_name[]);

