#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "func.h"


// THIS FUNCTION IS USED FOR GENERATING A NEW NODE I.E. GETTING MEMORY FOR OUR STRUCTURE
struct EMP_DATABASE* getnode()
{
	struct EMP_DATABASE *temp;
	temp = (struct EMP_DATABASE*) malloc(sizeof(struct EMP_DATABASE));
	return temp;
}

// THIS FUNCTION SEARCHES FOR RECORD FOR WHICH USER HAS PROVIDED AN ID
void Search(struct HASHTABLE hashtable[], int Emp_id)
{
	int Index = Emp_id % 1000;;

	struct EMP_DATABASE *temp;

	temp = hashtable[Index].link;
	
	// THIS CONDITION IS USED WHEN THE INDEX IS NOT USED I.E. THEIR IS NOTHING IN THAT BLOCK OF HASH-TABLE
	if(temp == NULL)
	{
		printf("NO RECORD EXIST\n");
		return;
	}
	else
	{
		// THIS WHILE LOOP IS USED WHEN WE HAVE TO FIND ID WITH SIMILAR INDEXs
		while(temp->Emp_id != Emp_id && temp != NULL)
		{
			temp = temp->link;
		}
		
		// THIS CONDITION IS APPLICABLE, IF INDEX IS AVAILABLE BUT THEIR IS NO ID IN THE LINKED LIST
		if(temp == NULL)
		{
			printf("NO RECORD EXIST\n");
			return;
		}
		// THIS CONDITION IS APPLICABLE, IF WE HAVE THE INDEX AND WE HAVE FOUND OUT THE ID SPECIFIED BY USER		
		else
		{
			printf("EMPLOYEE ID   - %d\n",temp->Emp_id);			
			printf("EMPLOYEE NAME - %s\n",temp->Emp_name);
			return;
		}
	}

}


// THIS FUNCTION IS USED TO INSERT A RECORD IN THE LINKED LIST SPECIFIED BY A PARTICULAR INDEX USING HASH FUNCTION
void Insert(struct HASHTABLE hashtable[], int Emp_id, char Emp_name[])
{
	int Index;

	struct EMP_DATABASE *temp, *newnode;
	
	// THIS IS OUR HASH FUNCTION
	Index = Emp_id % 1000;
	
	// NOW WE ARE STORING THE DATA OF THE HASH TABLE AT THE PARTICULAR INDEX IN TEMP VARIABLE
	temp = hashtable[Index].link;
	
	// THIS CONDITION WILL WORK WHEN THE INDEX IS NOT USED, IT IS THE FIRST TIME WE ARE USING IT 
	// ADDING A NODE INTO IT 
	if(temp == NULL)
	{
		newnode = getnode();

		newnode->Emp_id = Emp_id;
		strcpy(newnode->Emp_name, Emp_name);
		newnode->link = NULL;
		
		// THIS STATEMENT WILL LINK THE HASHTABLE LINK TO NEWNODE ADDRESS
		hashtable[Index].link = newnode;

		return;
	}
	// THIS CONDITION WILL WHEN WE HAVE A NODE AT THE INDEX AND WE WANT TO INSERT A NEWNODE WITH THE SAME INDEX
	else
	{
		
		newnode=getnode();

		newnode->Emp_id = Emp_id;
		strcpy(newnode->Emp_name, Emp_name);
		
		// SO WHAT WE DO IS THAT WE INSERT THE NEWNODE AT THE BEGINNING OF THE LINKED LIST  
		newnode->link = temp;	
		// AND THEN CHANGE THE ADDRESS ACCORDINGLY
		hashtable[Index].link = newnode;

		return;
		
	}	
}
