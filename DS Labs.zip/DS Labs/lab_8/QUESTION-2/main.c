#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "func.h"

int main()
{
	int Emp_id, index, choice;
	char Emp_name[20];
	
	// HERE WE ARE MAKING ARRAY OF SIZE 1000 OF TYPE HASHTABLE WHICH WILL ONLY CONTAIN THE LINKs
	struct HASHTABLE hashtable[1000];
	
	// THIS IS DONE IN ORDER FOR INSERT OPERATION TO WORK
	for(index = 0; index < 1000; index++)
	{
		// HERE WE ARE ASSGINING EACH LINK OF THE ARRAY TO BE NULL
		hashtable[index].link = NULL;
	}

	while(1)
	{	
		printf("ENTER A CHOICE:\n\n");	
		printf("1.INSERT A RECORD IN EMPLOYEE DATABASE\n");
		printf("2.SEARCH AN EMPLOYEE RECORD FROM DATABASE\n");
		printf("3.EXIT\n");	
		
		scanf("%d", &choice);
		switch(choice)
		{
			case 1:
				printf("ENTER EMPLOYEE ID: \n");
				scanf("%d", &Emp_id);
				printf("ENTER EMPLOYEE NAME: \n");
				scanf("%s", Emp_name);
				// CALLING THE Insert() FUNCTION TO INSERT EMPLOYEE RECORD IN THE DATABASE
				Insert(hashtable, Emp_id, Emp_name);
				break;
			case 2:
				printf("ENTER EMPLOYEE ID: \n");
				scanf("%d", &Emp_id);
				// CALLING THE Search() FUNCTION TO SEARCH A PARTICULAR EMPLOYEE RECORD IN THE DATABASE
				Search(hashtable, Emp_id);
				break;
			case 3:
				exit(0);
			default:
				printf("INVALID CHOICE\n");
				break;
		}	
	}
	return 0;
}
