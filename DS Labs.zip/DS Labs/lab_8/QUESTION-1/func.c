#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "func.h"

// THIS IS THE Search() FUNCTION WHICH IS USED TO SEARCH A PARTICULAR EMPLOYEE RECORD IN THE DATABASE USING THE EMPLOYEE UNIQUE ID
void Search(struct EMP_DATABASE Database[], int Emp_id)
{
	// THIS IS THE WAY OUR PROGRAM GENERATE THE INDEX FOR A PARTICULAR ID
	// THIS MAY ALSO BE CALLED AS HASH FUNCTION
	int Index = Emp_id % 2000;

	int i;
	
	// THIS FOR LOOP IS USED TO DETECT THE INDEX AT WHICH THE PARTICULAR ID IS STORED	
	for(i = 0; i < 2000; i++)
	{
		// THIS IS THE CONDITION WHICH ENSURES WE GET THE CORRECT RECORD WHICH WE ARE SEARCHING 
		if(Database[(Index + i) % 2000].Emp_id == Emp_id)
		{
			Index = (Index + i) % 2000;
			break;
		}	
	}
		
	printf("EMPLOYEE ID   - %d\n",Database[Index].Emp_id);
	printf("EMPLOYEE NAME - %s\n",Database[Index].Emp_name);

}


// THIS IS THE Insert() FUNCTION WHICH IS USED TO INSERT NEW EMPLOYEE RECORD IN THE EXISTING DATABASE
void Insert(struct EMP_DATABASE Database[], int Emp_id, char Emp_name[])
{
	// THIS IS THE HASH FUNCTION OR THE INDEX GENERATOR TO PUT THE RECORD IN THE DATABASE	
	int Index = Emp_id % 2000;
	
	// THIS WHILE LOOP IS USED, SO THAT WHENEVER WE GET SAME INDEX WE PUT THE RECORD IN DIFFERENT INDEX I.E. LINEAR PROBING TECHNIQUE
	while(Database[Index].Emp_id != 0) 
	{
		if(Index == 1999)
		{
			Index = 0;
			continue;
		}
		Index++;
   	}
	// HERE WE ARE ACTUALLY INSERTING THE DATA IN THE DATABASE
	Database[Index].Emp_id = Emp_id;
	strcpy(Database[Index].Emp_name, Emp_name);

}


