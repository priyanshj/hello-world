// EMPLOYEE DATABASE STRUCTURE FORMAT
struct EMP_DATABASE
{
	int Emp_id;
	char Emp_name[20];
};

// DECLARATION OF THE FUNCTION USED IN THE PROGRAM TO PERFORM SIMPLE TASKS
void Search(struct EMP_DATABASE Database[], int Emp_id);
void Insert(struct EMP_DATABASE Database[], int Emp_id, char Emp_name[]);

