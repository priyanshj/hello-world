#include<stdio.h>
#include<stdlib.h>
#include"plagrism.h"

void insertA(int x)
{
   struct node* temp;
  temp=(struct node*)malloc(sizeof(struct node*));
  
  temp->data=x;
  temp->next=headA;
  headA=temp;
}


void insertB(int x)
{
  struct node* temp;
  temp=(struct node*)malloc(sizeof(struct node*));
  
  temp->data=x;
  temp->next=headB;
  headB=temp;
}

void insert(int x)
{
  struct node* temp=(struct node*)malloc(sizeof(struct node*));
  
  temp->data=x;
  temp->next=head;
  head=temp;
}

void check()
{
  struct node* temp;
  struct node* temp2;
 
  temp=headA;
  temp2=headB;

  while(temp != NULL)
   {
     while(temp2 != NULL)
     {
       if(temp->data!=temp2->data)
        {
           printf("%d %d\n",temp->data,temp2->data);
           insert(temp2->data);
        }
       else
         {
           printf("data\n");
         }
        
          temp2=temp2->next;

     }
         temp2=headB;
        temp=temp->next;
   }
  
  
} 

void print()
{
  struct node* temp;

   temp=head;
  while(temp->next != NULL)
  {
   
   printf("%d",temp->data);
   temp=temp->next;
  }
   printf("%d",temp->data); 
}
