#include<stdio.h>

main()
{
 int A[1000],num,i=0,j=0,search;
 
 printf("Enter the Number of Values\n");
 
 scanf("%d",&num);

 for(i=0;i<num;i++)
 {
  scanf("%d",&A[i]);
 }

 printf("Enter the value you want to search\n");
 
 scanf("%d",&search);

 for(j=0;j<num;j++)
  {
    if(A[j]==search)
     {
       printf("%d Got it !\n",search);
       break;
     }
     else;
  }
}
