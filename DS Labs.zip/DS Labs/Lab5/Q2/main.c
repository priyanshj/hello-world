#include<stdio.h>
#include<stdlib.h>

struct node
{
	int row;
	int col;
	int value;
	struct node* next;
};

struct node* head1=NULL;
struct node* temp1=NULL;
struct node* head2=NULL;
struct node* temp2=NULL;
struct node* head3=NULL;
struct node* temp3=NULL;


struct node* create()
{

	struct node* sparse=(struct node*)malloc(sizeof(struct node));
	return sparse;
}

void Insert(int row,int col,int value,struct node* head)
{
    struct node* temp=head;
    struct node* sparse=create();
    sparse->row=row;
    sparse->col=col;
    sparse->value=value;
    sparse->next=NULL;
	if(head==NULL)
	{
		head=sparse;
	}
	else
	{
	    while(temp->next!=NULL)
            temp=temp->next;
		temp->next=sparse;
	}
}

void Add()
{
	int sum;
	struct node* raw1=head1;
	struct node* raw2=head2;
	while(raw1!=NULL&&raw2!=NULL)
	{
		if(raw1->row==raw2->row)
		{
			if(raw1->col==raw2->col)
			{
				sum=(raw1->value)+(raw2->value);
				Insert(raw1->row,raw1->col,sum,head3);
				raw1=raw1->next;
				raw2=raw2->next;
			}
			else if(raw1->col>raw2->col)
			{
				Insert(raw2->row,raw2->col,raw2->value,head3);
				raw2=raw2->next;
			}
			else
			{
				Insert(raw1->row,raw1->col,raw1->value,head3);
				raw1=raw1->next;
			}
		}
		else if(raw1->row>raw2->row)
		{
			Insert(raw2->row,raw2->col,raw2->value,head3);
			raw2=raw2->next;
		}
		else
		{
			Insert(raw1->row,raw1->col,raw1->value,head3);
			raw1=raw1->next;
		}
	}
	if(raw2==NULL)
    {
        while(raw1!=NULL)
        {
             Insert(raw1->row,raw1->col,raw1->value,head3);
             raw1=raw1->next;
        }
    }
    else
        while(raw2!=NULL)
        {
             Insert(raw2->row,raw2->col,raw2->value,head3);
             raw2=raw2->next;
        }
        Print(head3);
}

void Transpose()
{
    int vary;
    struct node* abc=head1;
    while(abc!=NULL)
    {
        vary=abc->row;
        abc->row=abc->col;
        abc->col=vary;
        abc=abc->next;
    }
    Print(head1);

}

void Print(struct node* head)
{
	struct node* po1=head;
	while(po1!=NULL)
    {
        printf("%d %d %d\n",po1->row,po1->col,po1->value);
        po1=po1->next;
    }
}

int main()
{
	int n,x,row,col,value,y;
	printf("Enter values for MATRIX 1\n");
	while(1)
	{
		printf("\n 1 TO INPUT IN MATRIX-1\n 2 TO INPUT IN MATRIX-2\n 3 TO ADD\n 4 TO TRANSPOSE MATRIX-1\nPRESS 5 TO EXIT\n");
		scanf("%d",&n);
		switch(n)
		{
			case 1 : printf("ROW No. :");
				 scanf("%d",&row);
				 printf("COLUMN No. :");
				 scanf("%d",&col);
			 	 printf("VALUE :");
				 scanf("%d",&value);
				 Insert(row,col,value,head1);
				 break;
            		case 2 : printf("ROW No. :");
				 scanf("%d",&row);
				 printf("COLUMN No. :");
				 scanf("%d",&col);
			 	 printf("VALUE :");
				 scanf("%d",&value);
				 Insert(row,col,value,head2);
				 break;
            case 3 : Add();
                     break;
            case 4 : Transpose();
                     break;
            case 5 : exit(1);

		}

	}

}
