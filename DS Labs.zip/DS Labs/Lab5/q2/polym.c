#include<stdio.h>
#include<stdlib.h>
#include "polym.h"

struct poly* head=NULL;
struct poly* head2=NULL;

void insert(int i,int j)
{
   struct poly* temp;
   temp=(struct poly*)malloc(sizeof(struct poly));

   temp->coeff=i;
   temp->degree=j;
   temp->next=head;
   head=temp;
}


void insertB(int i,int j)
{
   struct poly* temp;
   temp=(struct poly*)malloc(sizeof(struct poly));

   temp->coeff=i;
   temp->degree=j;
   temp->next=head2;
   head2=temp;
}




void print()
{
   struct poly* temp;
   temp=head;
   
   while(temp->next!=NULL)
    {
     printf("%dx^%d+",temp->coeff,temp->degree);
     temp=temp->next; 
    }
    printf("%dx^%d",temp->coeff,temp->degree); 
    printf("\n");
}




void add(struct poly *a,struct poly *b)
{
   struct poly* temp;
   struct poly* temp2;

   temp=(struct poly*)malloc(sizeof(struct poly));
 
while(a->next != NULL)
{
     while(b->next != NULL)
     {
       if(a->degree == b->degree)
      {
         temp->coeff=(a->coeff + b->coeff);
         b=b->next;     
      }
       else
      {
        b=b->next;
      }
    }
 a=a->next;
 temp->degree=a->degree;
}
//print();  
}




struct poly* return_node()
{
 struct poly* temp1;

 temp1=head;

 while(temp1->next != NULL)
  {
    return temp1;
    temp1=temp1->next;
  }
    return temp1;

 struct poly* temp2;

 temp2=head2;

 while(temp1->next != NULL)
  {
    return temp2;
    temp2=temp2->next;
  }
    return temp2;
}
