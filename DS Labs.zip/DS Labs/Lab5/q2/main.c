#include<stdio.h>
#include<stdlib.h>
#include "polym.h"

//struct poly* head=NULL;
//struct poly* head2=NULL;

main()
{
  int k,num,x,y,num2;
  struct poly *add1,*add2;
  
  printf("Enter the degree of polynomial\n");
  scanf("%d",&num);
 
    for(k=0;k<=num;k++)
    {
     printf("Enter the %d term for polynomial 1\n",k+1);
      scanf("%d %d",&x,&y);
      insert(x,y);
      add1=return_node();
    
     printf("Enter the %d term for polynomial 2\n",k+1);
      scanf("%d %d",&x,&y);
      insert(x,y);
      add2=return_node();  
    
      add(add1,add2);
    }
      

print();
}


