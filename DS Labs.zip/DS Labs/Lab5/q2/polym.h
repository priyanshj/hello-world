struct poly{
int coeff;
int degree;
struct poly* next;
};

//struct poly* head=NULL;
//struct poly* head2=NULL;

void insert(int i,int j);
void insertB(int i,int j);
void print();
void add(struct poly* a,struct poly* b);
struct poly* return_node();

