#include<stdio.h>
#include<stdlib.h>

struct poly{
int coeff;
int degree;
struct poly* next;
};

struct poly* head=NULL;
struct poly* head2=NULL;
struct poly* head3=NULL;

void insert(int i,int j);
void insertB(int i,int j);
void print();
void add();
struct poly* return_node();

main()
{
  int k,num,x,y,num2;
  struct poly *add1,*add2;

  scanf("%d",&num);
 
    for(k=0;k<=num;k++)
    {
      scanf("%d %d",&x,&y);
      insert(x,y);
      //add1=return_node();
    
      
      scanf("%d %d",&x,&y);
      insertB(x,y);
      //add2=return_node(); 
       
    
      //add();
    }
add();      

print();
}




void insert(int i,int j)
{
   struct poly* temp;
   temp=(struct poly*)malloc(sizeof(struct poly));

   temp->coeff=i;
   temp->degree=j;
   temp->next=head;
   head=temp;
}


void insertB(int i,int j)
{
   struct poly* temp;
   temp=(struct poly*)malloc(sizeof(struct poly));

   temp->coeff=i;
   temp->degree=j;
   temp->next=head2;
   head2=temp;
}




void print()
{
   struct poly* temp;
   temp=head3;
   
   while(temp->next!=NULL)
    {
     printf("%dx^%d+",temp->coeff,temp->degree);
     temp=temp->next; 
    }
    printf("%dx^%d",temp->coeff,temp->degree); 
    printf("\n");
}




void add()
{
   struct poly* a;
   struct poly* b;
   struct poly* temp;

   temp=(struct poly*)malloc(sizeof(struct poly));
    a->next=head;
    b->next=head2;
 
while(a->next != NULL)
{
     while(b->next != NULL)
     {
       if(a->degree == b->degree)
      {
         temp->coeff=(a->coeff+b->coeff);
         b=b->next;     
      }
       else
      {
        b=b->next;
      }
    }
 a=a->next;
 temp->degree=a->degree;
 temp->next=head3;
 head3=temp;
}
//temp->next=head3;
//head3=temp;
//print();  
}




struct poly* return_node()
{
 struct poly* temp1;

 temp1=head;

 while(temp1->next != NULL)
  {
    return temp1;
    temp1=temp1->next;
  }
    return temp1;

 struct poly* temp2;

 temp2=head2;

 while(temp1->next != NULL)
  {
    return temp2;
    temp2=temp2->next;
  }
    return temp2;
}
