#include <stdio.h>
#include <stdlib.h>
#include "poly_linkedlist.h"

struct Poly* getnode()
{
	struct Poly* temp;
	temp = (struct Poly*) malloc(sizeof(struct Poly));
	return temp;
}

void Insert(struct Poly* temp, int coeff, int exp, struct Poly* ext)
{
	struct Poly* last = ext;
	temp->coeff = coeff;
	temp->exp = exp;
	temp->link = NULL;
	
	if(ext == NULL)
	{
		ext = temp;
	}
	
	while(last->next != NULL)
  	{
  		last = last->next;
  	}
  	last->next = temp;

}





