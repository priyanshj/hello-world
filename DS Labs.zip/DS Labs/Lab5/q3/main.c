#include <stdio.h>
#include <stdlib.h>
#include "poly_linkedlist.h"


void main ()
{
	int n, m;
	printf("ENTER THE TOTAL NUMBER OF TERMS IN POLYNOMIAL-1:\n");
	scanf("%d", &n);

	printf("ENTER THE TOTAL NUMBER OF TERMS IN POLYNOMIAL-2:\n");
	scanf("%d", &m);	
	return;
}
