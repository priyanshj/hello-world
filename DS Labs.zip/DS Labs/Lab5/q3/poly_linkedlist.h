struct Poly
{
	int coeff, exp;
	struct poly* link;

};

struct Poly* head = NULL;
struct Poly* head1 = NULL;
struct Poly* head2 = NULL;
struct Poly* head3 = NULL;
struct Poly* getnode();
void Insert(struct Poly* temp, int coeff, int exp, struct Poly* ext);





