#include<stdio.h>
#include<stdlib.h>

struct node
{
int data;
struct node* next;
};

struct node* front=NULL;
struct node* rear=NULL;

void enqueue(int x);
void dequeue();

int main()
{
int i,j,num;

scanf("%d",&num);

for(i=0;i<num;i++)
 {
  scanf("%d",&j);
  enqueue(j); 
 }
dequeue();
dequeue();
return 0;
}

void enqueue(int x)
{
struct node* temp;
temp=(struct node*)malloc(sizeof(struct node*));

if(front == NULL)
{
temp->data=x;
temp->next=NULL;
rear=front=temp;
}

else
{
temp->data=x;
temp->next=NULL;
rear->next=temp;
rear=temp;
}
}

void dequeue()
{
struct node* temp;
if(front==rear)
 {
  printf("Error\n");
  return;
 }
else if(front==NULL)
 {
  printf("Error\n");
  return;
 }
else
 {
  temp=front;
  printf("The deleted value is %d\n",temp->data);
  front=front->next;
 }
}
