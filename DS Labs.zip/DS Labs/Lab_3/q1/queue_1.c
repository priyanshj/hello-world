#include<stdio.h>
#include<stdlib.h>

void enqueue(int x);
int dequeue();
int Isempty();

int que[100];
int front=-1,rear=-1;

int main()
{
int i,j,num,a[100];

scanf("%d",&num);
for(i=0;i<num;i++)
 {
  scanf("%d",&j);
  enqueue(j);
 }
a[0]=dequeue();
a[1]=dequeue();
printf("dequeued elements are %d %d\n",a[0],a[1]);
}

void enqueue(int x)
{
 if(Isempty())
 {
  front=0;
  rear=0;
  que[rear]=x; 
 }
 else
 {
  rear++;
  que[rear]=x;
 }
}

int dequeue()
{
 if(Isempty())
 {
  printf("Error\n");
  return;
 }
 else
 {
  //printf("%d\n",front);
  //printf("%d\n",que[front]);
 return que[front];
 }
 ++front;
}

int Isempty()
{
 if(front==-1 && rear==-1)
 {
  return 1;
 }
 else
 {
  return 0;
 }
}
