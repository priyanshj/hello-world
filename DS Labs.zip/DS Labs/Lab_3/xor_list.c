#include<stdio.h>
#include<stdlib.h>

struct node{
int data;
struct node* lnk;
};

struct node* head;

struct node* XOR(struct node* a,struct node* b)
 {
   return (struct node*)((unsigned int)(a)^(unsigned int)(b));
 }

void insert(int x);
void print();

main()
{
int i,j,num=0;

scanf("%d",&num);
 for(i=0;i<num;i++)
  {
   scanf("%d",&j);
    insert(j); 
  }
print();
}

void insert(int x)
{
 struct node* temp;
 temp=(struct node*)malloc(sizeof(struct node*));
 temp->data=x;
 temp->lnk=XOR(head,NULL);

  if(head!=NULL)
  {
   struct node* next=XOR((head)->lnk,NULL);
    head->lnk=XOR(temp,next);
  }
   head=temp;
}

void print()
{
 struct node* temp=head;
 struct node* next;
 struct node* prev=NULL;

 while(temp!=NULL)
 {
   printf("%d\n",temp->data);
   next=XOR(prev,temp->lnk);
   prev=temp;
   temp=next;
 }
}
