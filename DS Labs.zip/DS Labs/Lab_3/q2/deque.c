#include<stdio.h>
#include<stdlib.h>
#include"deque.h"

struct node* head=NULL;
struct node* tail=NULL;

void enque_front(int x)
{ 
  struct node* temp;
  temp=(struct node*)malloc(sizeof(struct node*));
  
  if(head==NULL || tail==NULL)
  {
  temp->data=x;
  temp->next=head;
  tail=head=temp;
  }
  
  else
  {
   temp->data=x;
   temp->next=head;
   head=temp;
  }  
}

void enque_rear(int x)
{
  struct node* temp;
  struct node* temp2;
  temp2=(struct node*)malloc(sizeof(struct node*));
  
   temp2=tail;
   temp2->next=NULL;
}

void print()
{
  struct node* temp;
  temp=head;
 
  while(temp->next != NULL)
   {
    printf("%d",temp->data);
    temp=temp->next;
   }
    printf("%d",temp->data);
}


