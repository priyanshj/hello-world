struct node{
int data;
struct node* next;
};

struct node* head;
struct node* tail;

void enque_front(int x);
void enque_rear(int x);
void deque_front();
void deque_rear();
void print();


