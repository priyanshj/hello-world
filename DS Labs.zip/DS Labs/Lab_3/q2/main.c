#include <stdio.h>
#include <stdlib.h>
#include "func.h"

void main()
{
	struct deck* deque = create_deck(100);
	DequeueRear(deque);
	EnqueueRear(deque, 10);
	EnqueueFront(deque, 20);
	return;
}
