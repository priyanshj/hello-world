#include <stdio.h>
#include <stdlib.h>
#include "func.h"

struct deck* create_deck(int capacity)
{
	struct deck* deque = (struct deck*) malloc(sizeof(struct deck));
	deque->capacity = capacity;
	deque->size = deque->front = 0;
	deque->rear = capacity - 1;
	deque->array = (int*) malloc(capacity * sizeof(int));
	return deque;
}


int isEmpty(struct deck* deque)
{
	return(deque->size == 0);	
}


int isFull(struct deck* deque)
{
	return(deque->size == deque->capacity);	
}


void EnqueueRear(struct deck* deque, int item)
{
	if(isFull(deque))
	{
		printf("STACK OVERFLOW\n");
    		return;	 
    	}
    	deque->rear = (deque->rear + 1) % deque->capacity;
    	deque->size = deque->size + 1;
    	deque->array[deque->rear] = item;
    	printf("%d ENQUEUED TO REAR OF THE DECK\n", item);
}


void EnqueueFront(struct deck* deque, int item)
{
	if(isFull(deque))
        {
                printf("STACK OVERFLOW\n");
                return;
        }
	deque->front = (deque->capacity + deque->front - 1) % deque->capacity;
	deque->size = deque->size + 1;
	deque->array[deque->front] = item;
	printf("%d ENQUEUED TO FRONT OF THE DECK\n", item);	
}


int DequeueRear(struct deck* deque)
{
	if(isEmpty(deque))
        {
                printf("STACK UNDERFLOW\n");
                return 0;
        }
	int item = deque->array[deque->rear];
	deque->size = deque->size - 1;
	deque->rear = (deque->capacity + deque->rear - 1) % deque->capacity;
	printf("%d DEQUEUED FROM REAR OF THE DECK\n", item);
	return item;	
}


int DequeueFront(struct deck* deque)
{
	if(isEmpty(deque))
    	{
		printf("STACK UNDERFLOW\n");
		return 0;
    	}
    	int item = deque->array[deque->front];
    	deque->size = deque->size - 1;
    	deque->front = (deque->front + 1) % deque->capacity;
    	printf("%d DEQUEUED FROM FRONT OF THE DECK\n", item);
    	return item;
}


