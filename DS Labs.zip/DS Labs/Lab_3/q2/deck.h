// ARRAY BASED IMPLEMENTATION OF DEQUE(DOUBLE ENDED QUEUE):

struct deck
{
	int size, capacity, front, rear;
	int *array;

};

struct deck* create_deck(int capacity);
int isEmpty(struct deck* deque);
int isFull(struct deck* deque);
void EnqueueRear(struct deck* deque, int item);
void EnqueueFront(struct deck* deque, int item);
int DequeueFront(struct deck* deque);
int DequeueRear(struct deck* deque);

