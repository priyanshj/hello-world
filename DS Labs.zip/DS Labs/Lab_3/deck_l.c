#include<stdio.h>
#include<stdlib.h>

struct node
{
int data;
struct node* next;
};

struct node* front=NULL;
struct node* rear=NULL;

void enqueue(int x);
void dequeue();
void rev_enqueue(int x);
void rev_dequeue();
void print();

int main()
{
 int i,j,num;
 
 scanf("%d",&num);
 
 for(i=0;i<num;i++)
  {
   scanf("%d",&j);
   enqueue(j);
   printf("Enqueue running perfect\n");
   rev_enqueue(j);
   printf("rev run perfect\n");
  }
   printf("loop run perfect\n");
  dequeue();
  dequeue();
   printf("deque run perfect\n");
  rev_dequeue();
   printf("rev_deque run perfect\n");
  print();
}

void enqueue(int x)
{
 struct node* temp;
 
 temp=(struct node*)malloc(sizeof(struct node*));

 if(front==NULL)
  {
   temp->data=x;
   temp->next=NULL;
   rear=front=temp;
  }
 else
  {
    temp->data=x;
    temp->next=NULL;
    rear->next=temp;
    rear=temp;
 
  }
}

void dequeue()
{
 struct node* temp;
 temp=front;
 front=front->next;
}

void rev_enqueue(int x)
{
 struct node* temp;
 temp=(struct node*)malloc(sizeof(struct node*));
 temp->data=x;
 temp->next=front;
 front=temp;
}

void rev_dequeue()
{
 struct node* temp;
 temp=front;
  printf(".....");
 while(temp->next!=rear)
 {
  temp=temp->next;
  printf("%d\n",temp->data);
 }
 
  rear=temp;
  temp->next=NULL; 
}

void print()
{
 struct node* temp;
 temp=front;
 while(temp!=NULL)
  {
    printf("%d\n",temp->data);
    temp=temp->next; 
  }
}
