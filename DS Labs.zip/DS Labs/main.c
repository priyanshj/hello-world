#include<stdio.h>
#include<stdlib.h>
#include"plagrism.h"

main()
{
  int i,j,k,p,num;

  scanf("%d",&num);

  for(i=1;i<=num;i++)
  {
    scanf("%d",&j);
    insertA(j);
  }
  for(p=0;p<num;p++)
  {
    scanf("%d",&k);
    insertB(k);
  }
    printf("print is fine\n");
    check();
    print();
}
