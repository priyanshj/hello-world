struct node{
int key;
struct node *left,*right
};

struct node* getNode(int data,struct node* root);
struct node* search(int data,struct node* root);
struct node* max(struct node* root);
struct node* min(struct node* root);
void inorder(struct node* root);
void preorder(struct node* root);
void postorder(struct node* root);

