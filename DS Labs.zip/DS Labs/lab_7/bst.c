#include<stdio.h>
#include<stdlib.h>
#include"bst.h"

struct node* insert(int data,struct node* tree)
{
   if(tree == NULL)
   {
    getNode(data);
   }

   if(key < tree->key)
   {
    tree->left = insert(data,tree->left);
   }
   else if(key > tree->key)
   {
    tree->right = insert(data,tree->right);
   }
  return tree;
}


struct node* getNode(int data)
{
  struct node* tree = (struct node*)malloc(sizeof(struct node*));
  
  tree->key = data;
 
  tree->left=NULL;
  tree->right=NULL;

  return tree;
}


int max(struct node* root)
{
  while(root->right != NULL)
  {
    root = root->right;
  }
return (root->data);
} 


int min(struct node* root)
{
  while(root->left != NULL)
  {
    root = root->left;
  }
return(root->data);
}


void inorder(struct node* root)
{
  if(root != NULL)
  {
   inorder(root->left);
    printf("%d\n",root->data);
   inorder(root->right);
  }
}


void postorder(struct node* root)
{
  if(root != NULL)
  {
    postorder(root->left);
    postorder(root->right);
    printf("%d\n",root->data);
  }
}


void preorder(struct node* root)
{
  if(root != NULL)
  {
    printf("%d\n",root->data);
    preorder(root->left);
    preorder(root->right);
  }
}


struct node* deleteNode(struct node* root, int key)
{
    
    if (root == NULL)
    { 
     return root;
    }
    

    if (key < root->key)
        {
         root->left = deleteNode(root->left, key);
        }
    
    else if (key > root->key)
        {
         root->right = deleteNode(root->right, key);
        }
    

    else
    {
        
        if (root->left == NULL)
        {
            struct node *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            struct node *temp = root->left;
            free(root);
            return temp;
        }
 
        
        struct node* temp = minValueNode(root->right);
        root->key = temp->key;
        root->right = deleteNode(root->right, temp->key);
    }
    return root;
}

