#include<stdio.h>
#include<stdlib.h>
#include"balance.h"


int height(struct node* node)
{
  if(node == NULL)
   {
     return 0;
   }

   return 1 + max_num(height(node->left),height(node->right)); 
}


int max_num(int i,int j)
{
  if( i >= j)
  {
    return i;
  }
   
  else
  {
    return j;
  }
}


int isbalanced(struct node* root)
{
  int left_h = 0;
  int right_h = 0;
 
  if(root == NULL)
  {
    return 1;
  }

  left_h = height(root->left);
  right_h = height(root->right);

  if(left_h-right_h <= 1 && left_h-right_h >= 1 && isbalanced(root->right) && isbalanced(root->left))
  {
    return 1;
  }
   
    return 0;
}

struct node* insert(struct node* tree,int data)
{
   if(tree == NULL)
   {
    return getNode(data);
   }

   if(data < tree->key)
   {
    tree->left = insert(tree->left,data);
   }
   else if(data > tree->key)
   {
    tree->right = insert(tree->right,data);
   }
  return tree;
}


struct node* getNode(int data)
{
  struct node* tree = (struct node*)malloc(sizeof(struct node*));
  
  tree->key = data;
 
  tree->left=NULL;
  tree->right=NULL;

  return tree;
}


int max(struct node* root)
{
  while(root->right != NULL)
  {
    root = root->right;
  }
return (root->key);
} 


int min(struct node* root)
{
  while(root->left != NULL)
  {
    root = root->left;
  }
return(root->key);
}


void inorder(struct node* root)
{
  if(root != NULL)
  {
   inorder(root->left);
    printf("%d\n",root->key);
   inorder(root->right);
  }
}


void postorder(struct node* root)
{
  if(root != NULL)
  {
    postorder(root->left);
    postorder(root->right);
    printf("%d\n",root->key);
  }
}


void preorder(struct node* root)
{
  if(root != NULL)
  {
    printf("%d\n",root->key);
    preorder(root->left);
    preorder(root->right);
  }
}


/*struct node* deleteNode(struct node* root, int key)
{
    
    if (root == NULL)
    { 
     return root;
    }
    

    if (key < root->key)
        {
         root->left = deleteNode(root->left, key);
        }
    
    else if (key > root->key)
        {
         root->right = deleteNode(root->right, key);
        }
    

    else
    {
        
        if (root->left == NULL)
        {
            struct node *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            struct node *temp = root->left;
            free(root);
            return temp;
        }
 
        
        struct node* temp = min(root->right);
        root->key = temp->key;
        root->right = deleteNode(root->right, temp->key);
    }
    return root;
}*/

