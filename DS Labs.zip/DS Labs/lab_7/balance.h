struct node{
int key;
struct node *left,*right;
};

struct node* getNode(int data);
struct node* search(int data,struct node* root);
int max(struct node* root);
int min(struct node* root);
void inorder(struct node* root);
void preorder(struct node* root);
void postorder(struct node* root);
struct node* insert(struct node* tree,int data);

int isbalanced(struct node* root);
int height(struct node* root);
int max_num(int i,int j);
