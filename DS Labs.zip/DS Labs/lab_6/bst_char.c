#include<stdio.h>
#include<stdlib.h>
#include"bst_char.h"

void inorder(struct tree* root)
{
  if(root != NULL)
  {
   inorder(root->left);
    printf("%c\n",root->data);
   inorder(root->right);
  }
}


void postorder(struct tree* root)
{
  if(root != NULL)
  {
    postorder(root->left);
    postorder(root->right);
    printf("%c\n",root->data);
  }
}


void preorder(struct tree* root)
{
  if(root != NULL)
  {
    printf("%c\n",root->data);
    preorder(root->left);
    preorder(root->right);
  }
}
 

void printLevelOrder(struct tree* root)
{
    int h = height(root);
    int i;
    for (i=1; i<=h; i++)
        printGivenLevel(root, i);
}
 
/* Print nodes at a given level */
void printGivenLevel(struct tree* root, int level)
{
    if (root == NULL)
        return;
    if (level == 1)
        printf("%d ", root->data);
    else if (level > 1)
    {
        printGivenLevel(root->left, level-1);
        printGivenLevel(root->right, level-1);
    }
}
 

int height(struct tree* root)
{
    if (root==NULL)
        return 0;
    else
    {
        /* compute the height of each subtree */
        int lheight = height(root->left);
        int rheight = height(root->right);
 
        /* use the larger one */
        if (lheight > rheight)
            return(lheight+1);
        else return(rheight+1);
    }
}



struct tree* newNode(char key)
{
  struct tree* temp=(struct tree*)malloc(sizeof(struct tree*));

  temp->data = key;
  
  temp->left=NULL;
  temp->right=NULL;

  return(temp);
}

 
