#include<stdio.h>
#include<stdlib.h>
#include"bst.h"

main()
{
  struct node* root = NULL;
  int maximum=0,minimum=0;

 printf("Let's go\n");
  root=insert(root,50);
  root=insert(root,30);
  root=insert(root,20);
  root=insert(root,40);
  root=insert(root,60);
  root=insert(root,80);
  root=insert(root,55);
printf("insert works\n");
   deleteNode(root,60);
   //maximum=max(root);
   //minimum=min(root);
   preorder(root);
   postorder(root);
   inorder(root);
}
