#include<stdio.h>
#include<stdlib.h>
#include"bst.h"

struct node* insert(struct node* tree,int data)
{
   if(tree == NULL)
   {
    return getNode(data);
   }

   if(data < tree->key)
   {
    tree->left = insert(tree->left,data);
   }
   else if(data > tree->key)
   {
    tree->right = insert(tree->right,data);
   }
  return tree;
}


struct node* getNode(int data)
{
  struct node* tree = (struct node*)malloc(sizeof(struct node*));
  
  tree->key = data;
 
  tree->left=NULL;
  tree->right=NULL;

  return tree;
}


struct node* max(struct node* root)
{
  while(root->right != NULL)
  {
    root = root->right;
  }
return (root);
} 


struct node* min(struct node* root)
{
  while(root->left != NULL)
  {
    root = root->left;
  }
return(root);
}


void inorder(struct node* root)
{
  if(root != NULL)
  {
   inorder(root->left);
    printf("%d\n",root->key);
   inorder(root->right);
  }
}


void postorder(struct node* root)
{
  if(root != NULL)
  {
    postorder(root->left);
    postorder(root->right);
    printf("%d\n",root->key);
  }
}


void preorder(struct node* root)
{
  if(root != NULL)
  {
    printf("%d\n",root->key);
    preorder(root->left);
    preorder(root->right);
  }
}


struct node* deleteNode(struct node* root, int key)
{
    
    if (root == NULL)
    { 
     return root;
    }
    

    if (key < root->key)
        {
         root->left = deleteNode(root->left, key);
        }
    
    else if (key > root->key)
        {
         root->right = deleteNode(root->right, key);
        }
    

    else
    {
        
        if (root->left == NULL)
        {
            struct node *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            struct node *temp = root->left;
            free(root);
            return temp;
        }
 
        
        struct node* temp = min(root->right);
        root->key = temp->key;
        root->right = deleteNode(root->right, temp->key);
    }
    return root;
}

