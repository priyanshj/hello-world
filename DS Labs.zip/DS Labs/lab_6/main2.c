#include<stdio.h>
#include<stdlib.h>
#include"bst_char.h"

main()
{
  struct tree* root = NULL;

   /*creation of tree
       a
      / \
     c   b
    / \ / \ 
   d  e f  g
  */

  root = newNode('a');
  root->left = newNode('c');
  root->right = newNode('b');
  root->left->left = newNode('d');
  root->left->right = newNode('e');
  root->right->left = newNode('f');
  root->right->right = newNode('g');

  inorder(root);
  preorder(root);
  postorder(root);
}
