struct tree{
char data;
struct tree *left,*right;
};

void inorder(struct tree* root);
void preorder(struct tree* root);
void postorder(struct tree* root);
void printGivenLevel(struct tree* root, int level);
int height(struct tree* node);
struct node* getNode(char data);
struct tree* newNode(char key);
