struct Stack
{
	char data;
	struct Stack *link;
};

struct Stack *top;

int is_empty();
void push(char data);
char pop();
int pairmatch(char x, char y);
int isParanthesisBalanced(char exp[]);
