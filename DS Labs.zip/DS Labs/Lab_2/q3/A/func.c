#include <stdio.h>
#include <stdlib.h>
#include "func.h"

struct Stack *top = NULL;

int is_empty()
{
	return (!top);
}

void push(char data)
{
	struct Stack *temp = (struct Stack*) malloc(sizeof(struct Stack));
	if(temp == NULL)
  	{
  		printf("STACK OVERFLOW\n");
		return;
  	}
	
	temp->data = data;
	temp->link = top;
	top = temp;
}

char pop()
{
	char data;
	struct Stack *temp = top;
	
	if(top == NULL)
	{
		printf("STACK UNDERFLOW\n");
		exit(0);
	}
		
	data = temp->data;
	top = temp->link;
	free(temp);
	return data;
}


int pairmatch(char x, char y)
{
	if(x == '[' && y == ']')
	{
		return 1;
	}
 	else if(x == '{' && y == '}')
	{	
		return 1;
	}
	else if(x == '(' && y == ')')
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int isParanthesisBalanced(char exp[])
{
	int i = 0;
	
	while(exp[i])
	{
		if((exp[i] == '[') || (exp[i] == '{') || (exp[i] == '('))
		{
			push(exp[i]);
		}
		
		if((exp[i] == ']') || (exp[i] == '}') || (exp[i] == ')'))
		{
			if(top == NULL)
			{
				return 0;
			}
			else if(!pairmatch(pop(), exp[i]))
			{
				return 0;
			}
			
		}
		
		i++;
	}
	
	if(top == NULL)
	{
		return 1;
	}	
	else
	{
		return 0;
	}
}

