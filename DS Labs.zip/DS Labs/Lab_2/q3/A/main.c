#include <stdio.h>
#include <stdlib.h>
#include "func.h"

int main()
{
	char exp[100];
	int choice;
	while(1)
	{	
		printf("ENTER YOUR CHOICE:\n");
		printf("1.ENTER A CHARACTER EXPRESSION TO CHECK WHETHER IT IS BALANCED OR NOT\n");
		printf("2.EXIT\n");
		scanf("%d", &choice);

		switch(choice)
		{
			case 1:
				printf("ENTER THE CHARACTER EXPRESSION:\n");
				scanf("%s", exp);
				if(isParanthesisBalanced(exp))
				{	
					printf("EXPRESSION IS A BALANCED\n\n");
				}
				else
				{
					printf("EXPRESSION IS NOT A BALANCED\n\n");
				}
				break;
			
			case 2:
				exit(0);
			
			default:
				printf("INVALID EXPRESSION\n");
				break;
		}		
	}
	return 0;
}
