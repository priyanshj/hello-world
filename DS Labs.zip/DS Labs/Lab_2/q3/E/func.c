#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "func.h"

struct Stack *top = NULL;

int is_empty()
{
	return (!top);
}

void push(char data)
{
	struct Stack *temp = (struct Stack*) malloc(sizeof(struct Stack));
	if(temp == NULL)
  	{
  		printf("STACK OVERFLOW\n");
		return;
  	}
	
	temp->data = data;
	temp->link = top;
	top = temp;
}

char pop()
{
	char data;
	struct Stack *temp = top;
	
	if(top == NULL)
	{
		printf("STACK UNDERFLOW\n");
		exit(0);
	}
		
	data = temp->data;
	top = temp->link;
	free(temp);
	return data;
}

void reverse(char exp[])
{
	int n = strlen(exp), i;
	
	for(i = 0; i < n; i++)
	{
		push(exp[i]);
	}

	for(i = 0; i < n; i++)
	{
		exp[i] = pop();
	}
}

