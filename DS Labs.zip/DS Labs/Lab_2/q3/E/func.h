struct Stack
{
	char data;
	struct Stack *link;
};

struct Stack *top;

int is_empty();
void push(char data);
char pop();
void reverse(char exp[]);
