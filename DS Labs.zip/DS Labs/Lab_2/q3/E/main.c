#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "func.h"

int main()
{
	char exp[100], cpy[100];
	int choice;
	while(1)
	{	
		printf("ENTER YOUR CHOICE:\n");
		printf("1.ENTER A STRING WHICH YOU WANT TO REVERSE\n");
		printf("2.EXIT\n");
		scanf("%d", &choice);

		switch(choice)
		{
			case 1:
				printf("ENTER THE STRING:\n");
				scanf(" %[^\n]s", exp);
				strcpy(cpy, exp);
				reverse(exp);
				printf("REVERSE OF '%s' IS: '%s'\n\n" ,cpy ,exp);
				break;
			
			case 2:
				exit(0);
			
			default:
				printf("INVALID EXPRESSION\n");
				break;
		}		
	}
	return 0;
}
