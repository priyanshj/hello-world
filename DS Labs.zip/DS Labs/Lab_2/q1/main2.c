#include<stdio.h>
#include<stdlib.h>
#include"stack_list.h"

main()
{
int i;

is_empty();
push(1);
push(2);
push(3);
pop();
pop();
push(4);
push(5);
print();
}
