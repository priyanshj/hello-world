#include<stdio.h>
#include<stdlib.h>
#include"stack_list.h"

struct stack* head = NULL;


void push(int x)
{
  struct stack* temp = (struct stack*)malloc(sizeof(struct stack*));

  temp->data=x;
  temp->next=head;
  head=temp;
}


void pop()
{
  struct stack* temp;
  
  temp=head;
  head=temp->next;
  free(temp);
}


void is_empty()
{
 if(head==NULL)
  {
   printf("stack is empty\n");
  }
 else
  {
   printf("stack is full\n"); 
  }
}


void print()
{
 struct stack* temp;

 temp = head;

 while(temp != NULL)
 {
  printf("%d\n",temp->data);
  temp=temp->next;
 }
}
