#include<stdio.h>
#include<stdlib.h>

void push(int x);
void pop();
void is_empty();
void print();

int top=-1;
int A[100];

int main()
{
int num,i,j;

scanf("%d",&num);

for(i=0;i<num;i++)
 {
  scanf("%d",&j);
  push(j);
  //print();
 }
pop(j);
print();
}

void push(int x)
{
 //top++;
// printf("%d\n",top);
 A[++top]=x;
}

void pop()
{
 top--;
}

void print()
{
int i;

for(i=0;i<=top;i++)
{
 printf("%d\n",A[i]);
}
}
