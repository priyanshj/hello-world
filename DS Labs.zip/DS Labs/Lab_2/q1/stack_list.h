struct stack{
int data;
struct stack* next;
};

void push(int x);
void pop();
void is_empty();
void print();

struct stack* head;
