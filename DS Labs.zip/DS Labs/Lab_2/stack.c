#include<stdio.h>
#include<stdlib.h>
#include"stack.h"

struct node* head=NULL;

void push(int x)
{
   struct node* temp;
   temp=(struct node*)malloc(sizeof struct node*);
   temp->data=x;
   temp->next=head;
   head=temp;
}


int pop()
{
   struct node* temp;
   temp=head->next;
   head=temp;

}
