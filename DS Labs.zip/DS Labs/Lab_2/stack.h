struct node{
int data;
struct node* next;
};

struct node* head;

void push(int x);
int pop();
void isempty();
