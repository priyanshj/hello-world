#include<stdio.h>
#include<stdlib.h>

struct stack
{
 int data;
 struct stack *next;
};

struct stack *top=NULL;

void push(int x);
void pop();
void print();

int main()
{
int i,j,num;

scanf("%d",&num);

for(i=0;i<num;i++)
 {
  scanf("%d",&j);
  push(j);
 }
//pop();
//pop();
//print();
return 0;
}

void push(int x)
{
 struct stack *temp;
 temp=(struct stack*)malloc(sizeof(struct stack));
 temp->data=x;
 temp->next=top;
 top=temp;
}

void pop()
{
 struct stack *temp;
}
