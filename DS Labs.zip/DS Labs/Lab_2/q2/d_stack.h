struct stack
{
	int value[10];
	int top;
	int back;
};

struct stack* create();
void pusha(int x,struct stack* stack1);
void pushb(int x,struct stack* stack1);
int popa(struct stack* stack1);
int popb(struct stack* stack1);
int Isemptya(struct stack* stack1);
int Isemptyb(struct stack* stack1);
void Print(struct stack* stack1);

