#include<stdio.h>
#include<stdlib.h>
#include"d_stack.h"
#define MAXSIZE 10


struct stack* create()
{
	struct stack *stack1 = (struct stack*) malloc(sizeof(struct stack));
	stack1->top=-1;
	stack1->back=MAXSIZE;

	return stack1;
}

void pusha(int x,struct stack* stack1)
{
	if(stack1->top==stack1->back-1)
	{
		printf("Overflow\n");
		return;
	}
	else
	stack1->value[++stack1->top]=x;
}


void pushb(int x,struct stack* stack1)
{
	if(stack1->top==stack1->back-1)
	{
		printf("Overflow\n");
		return;
	}
	else
	stack1->value[--stack1->back]=x;
}

int popa(struct stack* stack1)
{
	int data;
	if(stack1->top==-1)
	{
		printf("Underflow in STACK-A\n");
		return -1;

	}
	else
	{
	data=stack1->value[stack1->top--];
	return data;
	}
}


int popb(struct stack* stack1)
{
	int data;
	if(stack1->back==MAXSIZE)
	{
		printf("Underflow in STACK-B\n");
		return -1;
	}
	else
	{
	data=stack1->value[stack1->back++];
	return data;
	}
}

int Isemptya(struct stack* stack1)
{
	if(stack1->top==-1)
		return 1;
	else 
		return 0;
}

int Isemptyb(struct stack* stack1)
{
	if(stack1->back==MAXSIZE)
		return 1;
	else 
		return 0;
}

void Print(struct stack* stack1)
{
	int i,j;
	for(i=0;i<=stack1->top;i++)
		printf("%d",stack1->value[i]);
	for(j=stack1->back;j<MAXSIZE;j++)
		printf("%d",stack1->value[j]);
}
