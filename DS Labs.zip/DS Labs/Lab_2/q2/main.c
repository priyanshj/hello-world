#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 10


int main()
{
	int i,j,n,x,flag,pop;
	struct stack* stack1 = create();
	while(1)
	{
		printf("\n1.PUSH-A\n2.PUSH-B\n3.POP-A\n4.POP-B\n5.Check ISEMPTY-A\n6.Check ISEMPTY-B\n7.PRINT\n8.EXIT\n");
		scanf("%d",&n);
		switch(n)
		{
			case 1 : scanf("%d",&x);
				 pusha(x,stack1);
				 Print(stack1);
				 break;
			case 2 : scanf("%d",&x);
				 pushb(x,stack1);
				 Print(stack1);
				 break;
			case 3 : 
				 pop=popa(stack1);
				 if(pop==-1)
				 {Print(stack1);
				 break;}
				 else
				 printf("%dPopped\n",pop);
				 Print(stack1);
				 break;
			case 4 : 
				 pop=popb(stack1);
				 if(pop==-1)
				 {Print(stack1);
				 break;}
				 else
				 printf("%dPopped\n",pop);
				 Print(stack1);
				 break;
			case 5 : 
				 flag=Isemptya(stack1);
				 if(flag==1)
				 printf("Stack A is Empty\n");
				 else
				 printf("Stack A is not Empty\n");
				 break;
			case 6 : 
				 flag=Isemptyb(stack1);
				 if(flag==1)
				 printf("Stack B is Empty\n");
				 else
				 printf("Stack B is not Empty\n");
				 break;
			case 7 : Print(stack1);
				 break;
			case 8 : exit(0);
			default:
				printf("INVALID CHOICE\n");
				break;
		}
	}
	
	
	
}
